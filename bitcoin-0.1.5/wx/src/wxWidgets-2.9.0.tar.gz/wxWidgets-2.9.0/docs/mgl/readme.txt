
  Welcome to wxWidgets/MGL

You have downloaded the MGL port of the wxWidgets GUI library.
This runs on top of SciTech MGL library (http://www.scitechsoft.com/)
that is available for variety of operating systems and comes with support
for embedded devices.

More information about the wxWidgets project as a whole
can be found at:

  http://www.wxwidgets.org/
  
Information on how to install can be found in the file 
install.txt


  Regards,

  The wxWidgets team

