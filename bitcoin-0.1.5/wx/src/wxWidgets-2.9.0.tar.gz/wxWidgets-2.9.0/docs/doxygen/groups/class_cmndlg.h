/////////////////////////////////////////////////////////////////////////////
// Name:        class_cmndlg.h
// Purpose:     Common Dialog classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_cmndlg Common Dialogs
@ingroup group_class

Common dialogs are ready-made dialog classes which are frequently used in an
application.

Related Overviews: @ref overview_cmndlg

*/

