/////////////////////////////////////////////////////////////////////////////
// Name:        class_richtext.h
// Purpose:     Rich Text classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_richtext Rich Text
@ingroup group_class

wxWidgets provides a set of generic classes to edit and print simple rich text
with character and paragraph formatting.

*/

