/////////////////////////////////////////////////////////////////////////////
// Name:        class_conv.h
// Purpose:     Conversion classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_conv.h 53883 2008-05-31 22:35:24Z VZ $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_conv Text Conversion
@ingroup group_class

These are the classes used for conversions between different text encodings.

*/

