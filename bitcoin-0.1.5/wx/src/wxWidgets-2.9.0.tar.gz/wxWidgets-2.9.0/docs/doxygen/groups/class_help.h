/////////////////////////////////////////////////////////////////////////////
// Name:        class_help.h
// Purpose:     Help classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_help Help
@ingroup group_class

Classes for loading and displaying help manuals or help informations in general.

*/

