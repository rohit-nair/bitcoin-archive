/////////////////////////////////////////////////////////////////////////////
// Name:        funcmacro_procctrl.h
// Purpose:     Process Control function and macro group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: funcmacro_gdi.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_funcmacro_procctrl Process Control
@ingroup group_funcmacro

The functions in this section are used to launch or terminate the other
processes.

*/

