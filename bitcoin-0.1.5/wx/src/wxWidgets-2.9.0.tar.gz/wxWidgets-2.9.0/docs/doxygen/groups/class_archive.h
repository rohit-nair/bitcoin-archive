/////////////////////////////////////////////////////////////////////////////
// Name:        class_archive.h
// Purpose:     wxArchive* classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_archive.h 60399 2009-04-26 19:41:08Z VZ $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_archive Archive support
@ingroup group_class

Classes for managing (eventually compressed) archives.

*/

