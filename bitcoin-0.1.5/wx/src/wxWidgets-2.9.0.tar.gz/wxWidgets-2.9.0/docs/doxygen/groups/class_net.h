/////////////////////////////////////////////////////////////////////////////
// Name:        class_net.h
// Purpose:     Networking classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_net Networking
@ingroup group_class

wxWidgets provides its own classes for socket based networking.

Related macros/global-functions group: @ref group_funcmacro_networkuseros

*/

