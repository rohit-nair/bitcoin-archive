/////////////////////////////////////////////////////////////////////////////
// Name:        class_media.h
// Purpose:     Multimedia classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_media Multimedia
@ingroup group_class

Classes for showing multimedia contents.

*/

