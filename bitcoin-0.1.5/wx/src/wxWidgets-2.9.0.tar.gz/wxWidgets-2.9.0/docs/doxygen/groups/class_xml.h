/////////////////////////////////////////////////////////////////////////////
// Name:        class_xml.h
// Purpose:     XML classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_xml XML
@ingroup group_class

Group of classes loading and saving XML documents (http://www.w3.org/XML/).

*/

