/////////////////////////////////////////////////////////////////////////////
// Name:        class_smartpointers.h
// Purpose:     Smart Pointer classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_smartpointers Smart Pointers
@ingroup group_class

wxWidgets provides a few smart pointer class templates.

*/

