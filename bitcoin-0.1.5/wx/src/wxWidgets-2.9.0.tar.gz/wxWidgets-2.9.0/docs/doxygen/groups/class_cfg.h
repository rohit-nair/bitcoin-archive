/////////////////////////////////////////////////////////////////////////////
// Name:        class_cfg.h
// Purpose:     Application and System configuration classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_cfg.h 60399 2009-04-26 19:41:08Z VZ $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_cfg Application and System configuration
@ingroup group_class

The classes in this section are used to handle application-wide settings
and system-wide settings.

*/

