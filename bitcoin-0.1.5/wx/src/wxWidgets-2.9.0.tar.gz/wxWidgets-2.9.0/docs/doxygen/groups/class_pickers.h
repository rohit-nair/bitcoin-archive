/////////////////////////////////////////////////////////////////////////////
// Name:        class_pickers.h
// Purpose:     Picker Control classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_pickers Picker Controls
@ingroup group_class

A picker control is a control whose appearance and behaviour is highly
platform-dependent.

*/

