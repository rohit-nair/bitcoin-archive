/////////////////////////////////////////////////////////////////////////////
// Name:        class_misc.h
// Purpose:     Miscellaneous classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_misc Miscellaneous
@ingroup group_class

Group of miscellaneous classes.

Related macros/global-functions group: @ref group_funcmacro_misc

*/

