/////////////////////////////////////////////////////////////////////////////
// Name:        class_dnd.h
// Purpose:     Clipboard and Drag & Drop classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_dc.h 52454 2008-03-12 19:08:48Z BP $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_dnd Clipboard and Drag & Drop
@ingroup group_class

Related Overviews: @ref overview_dnd

*/

