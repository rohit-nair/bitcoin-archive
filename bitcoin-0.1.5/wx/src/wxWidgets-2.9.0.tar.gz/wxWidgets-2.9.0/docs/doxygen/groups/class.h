/////////////////////////////////////////////////////////////////////////////
// Name:        class.h
// Purpose:     Main class group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class.h 60399 2009-04-26 19:41:08Z VZ $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class Full Class List by Category

This group contains all full class list groups. The @ref page_class_cat
provides a quick summary of these groups on one page.

*/

