/////////////////////////////////////////////////////////////////////////////
// Name:        class_bookctrl.h
// Purpose:     Book controls classes group docs
// Author:      wxWidgets team
// RCS-ID:      $Id: class_bookctrl.h 60399 2009-04-26 19:41:08Z VZ $
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_bookctrl Book Controls
@ingroup group_class

A book control contains pages of other controls.

Related overview: @ref overview_bookctrl

*/

