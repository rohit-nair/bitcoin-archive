#!/bin/sh
autoconf -B build/autoconf_prepend-include